nblocks = 4;

n1 = 1;
d1 = 1;
n2 = 1; 
d2 = [1 2 3];
n3 = 3; 
d3 = [0.01 3];
n4 = 1; 
d4 = 1;

blkbuild;

q = [1 0 0
     2 1 -3
     3 2 4
     4 0 0];

iu = [1 4];
iy = 3;

[A, B, C, D] = connect(a, b, c, d, q, iu, iy);
[Am, Bm, Cm, Dm] = minreal(A, B, C, D);

[y, x, t] = step(Am, Bm, Cm, Dm, 1);

plot(t, y)

n = length(t);

for i=1:n
    if y(i) == max(y)
        disp('TIMPUL PRIMULUI MAXIM: '), t1m = t(i)
        imax = i;
    end
end

disp('SUPRAREGLAJUL ESTE: '), f = max(y) - y(n)
disp('SUPRAREGLAJUL IN PROCENTE ESTE: '), fp = f*100/y(n)

for i = 1:imax
    if y(i + 1) >= 0.95 * y(n) & y(i) <= 0.95 * y(n)
        disp('TIMPUL DE REGLARE'), t1 = t(i + 1)
    end
end

k = 0;
for i = 1:n-1
    if y(i+1) <= y(n) & y(i) >= y(n) & k == 0
        imax2 = i;
        k = 1;
    end
end

for i = imax2:n
    v(i) = y(i);
end

disp("GRADUL DE AMORTIZARE: "), ga = 1 - (max(v) - y(n))/(max(y) - y(n))



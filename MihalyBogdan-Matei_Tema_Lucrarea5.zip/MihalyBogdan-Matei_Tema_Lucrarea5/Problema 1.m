nblocks = 6;

n1 = 1; d1 = 1;
n2 = 3; d2 = 1;
n3 = [40 5]; d3 = [8 0];
n4 = 5; d4 = [8 10 3];
n5 = 3; d5 = 1;
n6 = 1; d6 = 1;

blkbuild;

q = [1 0 0
     2 1 0
     3 2 -5
     4 3 6
     5 4 0
     6 0 0];
 
 iu = [1 6];
 iy = [4];
 
 [A, B, C, D] = connect(a, b, c, d, q, iu, iy);
 [Am, Bm, Cm, Dm] = minreal(A, B, C, D);
 
 [y, x, t] = step(Am, Bm, Cm, Dm, 1);
 
 plot(t, y)
 
 n = length(t);
 
 for j = 1:n
     if y(j) == max(y)
         disp('TIMPUL PRIMULUI MAXIM: '), t1m = t(j)
         jmax = j;
     end
 end
 
 disp('SUPRAREGLAJUL ESTE: '), f = max(y) - y(n)
 disp('SUPRAREGLAJUL IN PROCENTE: '), fp = f * 100/y(n)
 
 for j = 1:jmax
     if y(j+1) >= 0.95*y(n) & y(j) <= 0.95 * y(n)
         disp('TIMPUL DE PRIMA REGLARE: '), t1 = t(j+1)
     end
 end
 
 k = 0;
 for j=1:n-1
     if y(j + 1) <= y(n) & y(j) >= y(n) & k == 0
         jmax2 = j;
         k = 1;
     end
 end
 
 for j=jmax2:n
     v(j)=y(j);
 end
 
 disp('GRADUL DE AMORTIZARE: '), ga = 1 - (max(v) - y(n))/(max(y) - y(n))
     
  
 
 
 
 
 
 